/**
    @ignore value that shouldn't be here
*/
function foo(x) {

}
