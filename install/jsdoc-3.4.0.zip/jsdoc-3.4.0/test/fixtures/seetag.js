/**
*  @see {@link bar}
*/
function foo() {
}

/**
*  @see http://example.com/someref
*/
function bar() {
}
