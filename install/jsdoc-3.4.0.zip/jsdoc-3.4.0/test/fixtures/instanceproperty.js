/** @class */
function Foo() {}

/** Set the bar. */
Foo.prototype.setBar = function(bar) {
    /** The bar. */
    this.bar = bar;
};
