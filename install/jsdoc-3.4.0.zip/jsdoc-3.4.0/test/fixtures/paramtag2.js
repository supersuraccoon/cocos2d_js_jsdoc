/** @module mysocket */

/**
 * @param {string} - Hostname.
 * @param {number} - Port number.
 */
exports.open = function(hostname, port) {};
