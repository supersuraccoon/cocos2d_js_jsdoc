/**
* @constructor
*/
function Collection() {

    /** @readonly */
    this.length = 0;
}
