/** @module jacket */
define('jacket', function () {
    /**
     * Jacket constructor.
     *
     * @constructor
     * @alias module:jacket
     */
    function Jacket() {}

    return Jacket;
});
