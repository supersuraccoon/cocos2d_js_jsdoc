/** @module */
define({
    property: "foo",
    method: function() {}
});