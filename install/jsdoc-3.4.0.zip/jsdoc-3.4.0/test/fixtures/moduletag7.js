/** @module color/mixer */

export default {
    /** Blend two colors together. */
    blend: function(color1, color2) {}
};
