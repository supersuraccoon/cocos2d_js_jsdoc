class Test {
    /** Document me. */
    run() {
    }

    /** Static document me. */
    static run() {
    }
}
