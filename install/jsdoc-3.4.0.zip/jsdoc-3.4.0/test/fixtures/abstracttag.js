/** @constructor */
function Thingy() {

    /** @abstract */
    this.pez = 2;

}

// same as...

/** @constructor */
function OtherThingy() {

    /** @virtual */
    this.pez = 2;

}