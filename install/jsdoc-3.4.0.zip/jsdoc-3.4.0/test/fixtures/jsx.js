var myDivElement = <div className="foo" />;
React.render(myDivElement, document.getElementById('example'));
