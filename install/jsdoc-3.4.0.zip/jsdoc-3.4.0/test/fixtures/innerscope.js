/** @constructor */
function Message(to) {

    var headers = {},
        response;

    /** document me */
    headers.to = to;

    (function() {
        /** document me */
        response.code = '200';

        /** document me */
        headers.from = '';
    })()
}
