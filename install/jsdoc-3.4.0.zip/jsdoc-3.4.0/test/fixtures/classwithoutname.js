// JSDoc should not be able to identify the name of this class.

var MyClass = Class.define({
    /**
     * Create an instance of MyClass.
     * @constructs
     */
    initialize: function() {}
});
