'use strict';

/** @module template */

/**
 * @class
 * @alias module:template.Template
 */
var Template = exports.Template = function() {
    /** View file. */
    this.view = null;
};
