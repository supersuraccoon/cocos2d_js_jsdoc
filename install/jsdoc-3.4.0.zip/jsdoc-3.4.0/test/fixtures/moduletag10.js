/** @module foo */

export default function() {};
