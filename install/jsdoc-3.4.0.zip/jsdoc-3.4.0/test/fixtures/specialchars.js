'use strict';

/**
 * @class
 */
function Socket() {
    /** Port number. */
    this['port#number'] = 0;
}

/** Open a connection. */
Socket.prototype['open~a.connection#now'] = function() {};
