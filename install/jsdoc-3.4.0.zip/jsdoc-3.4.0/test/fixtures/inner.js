function sendMessage(text) {
    /** document me */
    var encoding = 'utf8';

    /** document me */
    function encrypt(){}
}