'use strict';

xdescribe('jsdoc/template', function() {
    // TODO
});
