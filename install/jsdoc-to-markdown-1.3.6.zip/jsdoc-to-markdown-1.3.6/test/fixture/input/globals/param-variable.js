/** 
This function takes variable input
@param prop {...string} - the property(s) as input
*/
function pluck (prop) {}

/**
@class
*/
function Plucker () {}

/** 
This function takes variable input
@param {string} - an input
@param {...string} - the property(s) as input
@param three {...string} - more input
*/
Plucker.prototype.doPluck = function (one, args) {}
