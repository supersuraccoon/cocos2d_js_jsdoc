/**
this function has a wonderful custom tag
@createdIn Nigeria
*/
function customTaggedFunction () {}
