/**
ensure you have some-module installed
@requires some-module
*/
function requirer () {}
