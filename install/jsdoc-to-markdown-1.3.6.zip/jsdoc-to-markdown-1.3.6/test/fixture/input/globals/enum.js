/**
Enum for the `type` value
@readonly
@enum {number}
*/
var eFileType = {
  NOEXIST: 0,
  FILE: 1,
  DIR: 2
}
