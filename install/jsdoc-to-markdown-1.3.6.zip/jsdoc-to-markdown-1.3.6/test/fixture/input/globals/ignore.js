/**
a visible global
*/
var visible = true

/**
an ignored global
@ignore
*/
var invisible = true
