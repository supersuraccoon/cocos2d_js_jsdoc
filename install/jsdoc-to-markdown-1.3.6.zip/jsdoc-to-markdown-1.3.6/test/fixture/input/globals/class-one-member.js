/**
@class
*/
function Pizza () {
  /**
  the general size
  */
  this.size = 'medium'
}
