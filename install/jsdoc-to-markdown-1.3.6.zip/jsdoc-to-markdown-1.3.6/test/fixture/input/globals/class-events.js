/**
@class
*/
function Rice () {}

/**
Fired when rice is ready
@event Rice#cooked
*/
/**
Fired when rice is cooking
@event Rice#cooking
*/
