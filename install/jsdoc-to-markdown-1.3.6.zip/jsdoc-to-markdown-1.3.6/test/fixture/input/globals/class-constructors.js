/**
a constructor description
@class
@classdesc simple class description
@extends {Object}
*/
function Person () {}
Person.prototype.methodOne = function () {}

/**
a constructor with args
@class
@param [options] {object} - optional shit
*/
function Car (options) {}

/**
@class
@classdesc a class which extends
@extends Pipe
*/
function Pipe () {}

/**
the constructor description
@class
@classdesc a class with all trimmings
@extends Pipe
@param {object} - an input
@param [options] {object} - optional shit
@author 75lb <75pound@gmail.com>
@deprecated
@since v0.10.28
@example
```js
var yeah = new Everything(true)
```
*/
function Everything (input, second) {}
