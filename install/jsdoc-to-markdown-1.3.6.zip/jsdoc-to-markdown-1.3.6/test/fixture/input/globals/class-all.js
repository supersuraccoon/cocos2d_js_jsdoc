/**
the constructor description
@class
@classdesc a class with all of the things
@param {object} - an input
@param [options] {object} - optional shit
@author 75lb <75pound@gmail.com>
@deprecated
@since v0.10.28
@extends {Number}
@example
```js
var yeah = new Everything(true)
```
*/
function All (input, second) {
  /**
  the ingredients on top
  @default
  @type {string}
  @since v1.0.0
  */
  this.topping = 'mud, lettuce'

  /**
  the general size
  */
  this.size = 'medium'
}

/**
This function has all tags set
@deprecated
@param {string} - The input string
@param {object} - a second input
@author Lloyd <75pound@gmail.com>
@since v0.10.28
@returns {object | string} this return has several types
@example
```js
all.allTogether(true)
```
*/
All.prototype.allThings = function (one, two) {
  /**
  a rarseclart inner
  */
  var some = 'bs code'
}
