/**
@param {object} options - the function options
@param {string} options.one - first option
@param {string} options.two - second option
*/
function doSomething (options) {}
