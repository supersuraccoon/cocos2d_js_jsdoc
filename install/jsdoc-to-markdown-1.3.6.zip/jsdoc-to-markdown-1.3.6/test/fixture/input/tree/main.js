var one = require('modules/one')
var two = require('modules/two')

/**
this is for something
@type {string}
*/
var something = one.one

/**
this is for something else
@type {string}
*/
var another = one.two
