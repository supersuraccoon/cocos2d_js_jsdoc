/**
module one yeah
@module
*/
exports.one = 1
