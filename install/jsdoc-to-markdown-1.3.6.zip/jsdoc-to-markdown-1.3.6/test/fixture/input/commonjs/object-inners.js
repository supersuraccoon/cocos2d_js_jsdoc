/**
exported object, with-inner-members
@module cattle
*/

/**
@returns {boolean}
*/
exports.createCow = function () {}

/**
the inner member
*/
var innerMember = 1

/**
the inner function
*/
function innerFuction () {}

/**
another inner function
@deprecated
*/
function anotherInnerFuction () {}
