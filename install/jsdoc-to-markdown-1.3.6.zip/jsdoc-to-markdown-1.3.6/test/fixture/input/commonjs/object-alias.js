/**
simple object export
@module
@alias _
*/

/**
first property
*/
exports.one = 1

/**
second property
*/
exports.two = 2

/**
a function
*/
exports.three = function (four, five) {}
