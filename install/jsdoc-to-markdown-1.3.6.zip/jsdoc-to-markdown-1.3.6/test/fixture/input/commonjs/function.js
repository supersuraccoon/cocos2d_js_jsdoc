/**
This is the module description
@module
@author Lloyd <75pound@gmail.com>
@since v0.10.28
*/

/**
the main function description
@param {string} - The input string
@param {object} - a second input
@returns {object | string} this return has several types
*/
module.exports = function (one, two) {}
