/**
This is the module description
@module function-tools
@variableName f
@context {customContext}
*/

/**
the main function description
*/
exports.one = function () {}
