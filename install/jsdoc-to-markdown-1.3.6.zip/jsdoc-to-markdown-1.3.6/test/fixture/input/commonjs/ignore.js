/**
module with ignored shiz
@module
@alias ignore
*/

/**
visible property
*/
exports.visible = 1

/**
invisible property
@ignore
*/
exports.invisible = 2
