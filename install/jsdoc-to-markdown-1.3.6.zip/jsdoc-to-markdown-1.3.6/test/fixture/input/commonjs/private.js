/**
module with private shiz
@module private
*/

/**
visible property
*/
exports.notprivate = 1

/**
isprivate property
@private
*/
exports.isprivate = 2
