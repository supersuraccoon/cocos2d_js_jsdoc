/**
this module exports one value, that's it
@module
*/

/**
@type {boolean}
@default
*/
module.exports = true
