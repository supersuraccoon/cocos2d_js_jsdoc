/**
 * A module representing a jacket.
 * @module jacket
 */
define('jacket', function () {
  /**
   * @constructor
   * @alias module:jacket
   */
  var Jacket = function () {}

  /** Open and close your Jacket. */
  Jacket.prototype.zip = function () {}

  return Jacket
})
