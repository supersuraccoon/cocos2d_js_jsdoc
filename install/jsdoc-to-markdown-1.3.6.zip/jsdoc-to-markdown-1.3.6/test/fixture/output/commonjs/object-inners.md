<a name="module_cattle"></a>
## cattle
exported object, with-inner-members


* [cattle](#module_cattle)
  * _static_
    * [.createCow()](#module_cattle.createCow) ⇒ <code>boolean</code>
  * _inner_
    * [~innerMember](#module_cattle..innerMember)
    * [~innerFuction()](#module_cattle..innerFuction)
    * ~~[~anotherInnerFuction()](#module_cattle..anotherInnerFuction)~~

<a name="module_cattle.createCow"></a>
### cattle.createCow() ⇒ <code>boolean</code>
**Kind**: static method of <code>[cattle](#module_cattle)</code>  
<a name="module_cattle..innerMember"></a>
### cattle~innerMember
the inner member

**Kind**: inner property of <code>[cattle](#module_cattle)</code>  
<a name="module_cattle..innerFuction"></a>
### cattle~innerFuction()
the inner function

**Kind**: inner method of <code>[cattle](#module_cattle)</code>  
<a name="module_cattle..anotherInnerFuction"></a>
### ~~cattle~anotherInnerFuction()~~
***Deprecated***

another inner function

**Kind**: inner method of <code>[cattle](#module_cattle)</code>  
