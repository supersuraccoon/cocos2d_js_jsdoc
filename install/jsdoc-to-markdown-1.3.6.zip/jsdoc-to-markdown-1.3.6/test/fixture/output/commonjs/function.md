<a name="module_function"></a>
## function
This is the module description

**Since**: v0.10.28  
**Author:** Lloyd <75pound@gmail.com>  
<a name="exp_module_function--module.exports"></a>
### module.exports(one, two) ⇒ <code>object</code> \| <code>string</code> ⏏
the main function description

**Kind**: Exported function  
**Returns**: <code>object</code> \| <code>string</code> - this return has several types  

| Param | Type | Description |
| --- | --- | --- |
| one | <code>string</code> | The input string |
| two | <code>object</code> | a second input |

