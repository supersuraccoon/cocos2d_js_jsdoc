<a name="module_ignore"></a>
## ignore
module with ignored shiz

<a name="module_ignore.visible"></a>
### ignore.visible
visible property

**Kind**: static property of <code>[ignore](#module_ignore)</code>  
