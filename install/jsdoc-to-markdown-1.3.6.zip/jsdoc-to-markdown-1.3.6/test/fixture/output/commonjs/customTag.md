<a name="module_function-tools"></a>
## function-tools
This is the module description

**Variablename**: f  
**Context**: <code>customContext</code>  
<a name="module_function-tools.one"></a>
### function-tools.one()
the main function description

**Kind**: static method of <code>[function-tools](#module_function-tools)</code>  
