<a name="module_one-member"></a>
## one-member
simple object, one member. It shouldn't have an index.

<a name="module_one-member.three"></a>
### one-member.three(four, five) ⇒ <code>object</code> \| <code>string</code>
a function

**Kind**: static method of <code>[one-member](#module_one-member)</code>  
**Returns**: <code>object</code> \| <code>string</code> - this return has several types  
**Since**: v0.10.28  
**Author:** Lloyd <75pound@gmail.com>  

| Param | Type | Description |
| --- | --- | --- |
| four | <code>string</code> | The input string |
| five | <code>object</code> | a second input |

**Example**  
```js
allTogether(true);
```
