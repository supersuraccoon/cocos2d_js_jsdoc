<a name="module_single-value"></a>
## single-value
this module exports one value, that's it

<a name="exp_module_single-value--module.exports"></a>
### module.exports : <code>boolean</code> ⏏
**Default**: <code>true</code>  
**Kind**: Exported member  
