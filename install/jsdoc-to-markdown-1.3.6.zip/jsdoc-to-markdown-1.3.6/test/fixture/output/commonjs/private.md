<a name="module_private"></a>
## private
module with private shiz

<a name="module_private.notprivate"></a>
### private.notprivate
visible property

**Kind**: static property of <code>[private](#module_private)</code>  
