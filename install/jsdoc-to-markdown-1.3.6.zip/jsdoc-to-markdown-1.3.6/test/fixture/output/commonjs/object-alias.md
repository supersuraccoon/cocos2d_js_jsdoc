<a name="module_object-alias"></a>
## object-alias
simple object export


* [object-alias](#module_object-alias)
  * [.one](#module_object-alias.one)
  * [.two](#module_object-alias.two)
  * [.three()](#module_object-alias.three)

<a name="module_object-alias.one"></a>
### object-alias.one
first property

**Kind**: static property of <code>[object-alias](#module_object-alias)</code>  
<a name="module_object-alias.two"></a>
### object-alias.two
second property

**Kind**: static property of <code>[object-alias](#module_object-alias)</code>  
<a name="module_object-alias.three"></a>
### object-alias.three()
a function

**Kind**: static method of <code>[object-alias](#module_object-alias)</code>  
