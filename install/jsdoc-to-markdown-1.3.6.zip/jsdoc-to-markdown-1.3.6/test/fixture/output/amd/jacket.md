<a name="module_jacket"></a>
## jacket
A module representing a jacket.


* [jacket](#module_jacket)
  * [Jacket](#exp_module_jacket--Jacket) ⏏
    * [.zip()](#module_jacket--Jacket#zip)

<a name="exp_module_jacket--Jacket"></a>
### Jacket ⏏
**Kind**: Exported class  
<a name="module_jacket--Jacket#zip"></a>
#### jacket.zip()
Open and close your Jacket.

**Kind**: instance method of <code>[Jacket](#exp_module_jacket--Jacket)</code>  
