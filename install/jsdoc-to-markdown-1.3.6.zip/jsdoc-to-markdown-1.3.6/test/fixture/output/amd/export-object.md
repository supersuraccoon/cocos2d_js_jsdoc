<a name="module_amd/export-object"></a>
## amd/export-object
A module that says hello!

<a name="module_amd/export-object.sayHello"></a>
### amd/export-object.sayHello()
Say hello.

**Kind**: static method of <code>[amd/export-object](#module_amd/export-object)</code>  
