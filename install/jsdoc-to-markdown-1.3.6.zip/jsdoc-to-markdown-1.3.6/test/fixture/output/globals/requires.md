<a name="requirer"></a>
## requirer()
ensure you have some-module installed

**Kind**: global function  
