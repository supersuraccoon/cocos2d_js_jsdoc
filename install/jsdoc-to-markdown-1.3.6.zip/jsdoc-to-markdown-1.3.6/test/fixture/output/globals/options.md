## Functions
<dl>
<dt><a href="#doSomething">doSomething(options)</a></dt>
<dd></dd>
<dt><a href="#doAnother">doAnother(options)</a></dt>
<dd></dd>
</dl>
<a name="doSomething"></a>
## doSomething(options)
**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>object</code> | the function options |
| options.one | <code>string</code> | first option |
| options.two | <code>string</code> | second option |

<a name="doAnother"></a>
## doAnother(options)
**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>Object</code> | the function options |

