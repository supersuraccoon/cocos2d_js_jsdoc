## Classes
<dl>
<dt><a href="#Plucker">Plucker</a></dt>
<dd></dd>
</dl>
## Functions
<dl>
<dt><a href="#pluck">pluck(...prop)</a></dt>
<dd><p>This function takes variable input</p>
</dd>
</dl>
<a name="Plucker"></a>
## Plucker
**Kind**: global class  
<a name="Plucker#doPluck"></a>
### plucker.doPluck(one, ...args, ...three)
This function takes variable input

**Kind**: instance method of <code>[Plucker](#Plucker)</code>  

| Param | Type | Description |
| --- | --- | --- |
| one | <code>string</code> | an input |
| ...args | <code>string</code> | the property(s) as input |
| ...three | <code>string</code> | more input |

<a name="pluck"></a>
## pluck(...prop)
This function takes variable input

**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| ...prop | <code>string</code> | the property(s) as input |

