<a name="visible"></a>
## visible
a visible global

**Kind**: global variable  
