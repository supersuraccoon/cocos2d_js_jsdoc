<a name="eFileType"></a>
## eFileType : <code>number</code>
Enum for the `type` value

**Kind**: global enum  
**Read only**: true  
**Properties**

| Name | Type | Default |
| --- | --- | --- |
| NOEXIST | <code>number</code> | <code>0</code> | 
| FILE | <code>number</code> | <code>1</code> | 
| DIR | <code>number</code> | <code>2</code> | 

