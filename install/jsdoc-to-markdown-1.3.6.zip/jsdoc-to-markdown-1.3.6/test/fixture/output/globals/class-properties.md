<a name="Pizza"></a>
## Pizza
**Kind**: global class  

* [Pizza](#Pizza)
  * [.topping](#Pizza#topping) : <code>string</code>
  * [.size](#Pizza#size)

<a name="Pizza#topping"></a>
### pizza.topping : <code>string</code>
the ingredients on top

**Default**: <code>&quot;mud, lettuce&quot;</code>  
**Kind**: instance property of <code>[Pizza](#Pizza)</code>  
**Since**: v1.0.0  
<a name="Pizza#size"></a>
### pizza.size
the general size

**Kind**: instance property of <code>[Pizza](#Pizza)</code>  
