## Constants
<dl>
<dt><a href="#CONST_ONE">CONST_ONE</a> : <code>number</code></dt>
<dd><p>the first important constant</p>
</dd>
<dt><del><a href="#CONST_TWO">CONST_TWO</a> : <code>boolean</code></del></dt>
<dd><p>This variable has all tags set</p>
</dd>
</dl>
<a name="CONST_ONE"></a>
## CONST_ONE : <code>number</code>
the first important constant

**Kind**: global constant  
<a name="CONST_TWO"></a>
## ~~CONST_TWO : <code>boolean</code>~~
***Deprecated***

This variable has all tags set

**Kind**: global constant  
**Read only**: true  
**Since**: v0.10.28  
**Author:** Lloyd Brookes <lloyd@brookes.com>  
**Example**  
```js
var CONST_TWO = true;
```
