## Classes

<dl>
<dt><a href="#Person">Person</a> ⇐ <code>Object</code></dt>
<dd><p>simple class description</p>
</dd>
<dt><a href="#Car">Car</a></dt>
<dd></dd>
<dt><a href="#Pipe">Pipe</a> ⇐ <code><a href="#Pipe">Pipe</a></code></dt>
<dd><p>a class which extends</p>
</dd>
<dt><del><a href="#Everything">Everything</a> ⇐ <code><a href="#Pipe">Pipe</a></code></del></dt>
<dd><p>a class with all trimmings</p>
</dd>
</dl>

<a name="Person"></a>
## Person ⇐ <code>Object</code>
simple class description

**Kind**: global class  
**Extends:** <code>Object</code>  
<a name="new_Person_new"></a>
### new Person()
a constructor description

<a name="Car"></a>
## Car
**Kind**: global class  
<a name="new_Car_new"></a>
### new Car([options])
a constructor with args


| Param | Type | Description |
| --- | --- | --- |
| [options] | <code>object</code> | optional shit |

<a name="Pipe"></a>
## Pipe ⇐ <code>[Pipe](#Pipe)</code>
a class which extends

**Kind**: global class  
**Extends:** <code>[Pipe](#Pipe)</code>  
<a name="Everything"></a>
## ~~Everything ⇐ <code>[Pipe](#Pipe)</code>~~
***Deprecated***

a class with all trimmings

**Kind**: global class  
**Extends:** <code>[Pipe](#Pipe)</code>  
**Since**: v0.10.28  
**Author:** 75lb <75pound@gmail.com>  
<a name="new_Everything_new"></a>
### new Everything(input, [options])
the constructor description


| Param | Type | Description |
| --- | --- | --- |
| input | <code>object</code> | an input |
| [options] | <code>object</code> | optional shit |

**Example**  
```js
var yeah = new Everything(true)
```
