<a name="doSomething"></a>
## doSomething(options)
**Kind**: global function  

| Param | Type | Description |
| --- | --- | --- |
| options | <code>object</code> | the function options |
| options.one | <code>string</code> | first option |
| options.two | <code>string</code> | second option |

