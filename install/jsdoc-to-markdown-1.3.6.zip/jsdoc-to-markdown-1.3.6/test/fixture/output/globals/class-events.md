<a name="Rice"></a>
## Rice
**Kind**: global class  

* [Rice](#Rice)
  * ["cooked"](#Rice#event_cooked)
  * ["cooking"](#Rice#event_cooking)

<a name="Rice#event_cooked"></a>
### "cooked"
Fired when rice is ready

**Kind**: event emitted by <code>[Rice](#Rice)</code>  
<a name="Rice#event_cooking"></a>
### "cooking"
Fired when rice is cooking

**Kind**: event emitted by <code>[Rice](#Rice)</code>  
