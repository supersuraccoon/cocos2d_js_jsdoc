<a name="All"></a>
## ~~All ⇐ <code>Number</code>~~
***Deprecated***

a class with all of the things

**Extends:** <code>Number</code>  
**Kind**: global class  
**Since**: v0.10.28  
**Author:** 75lb <75pound@gmail.com>  

* ~~[All](#All) ⇐ <code>Number</code>~~
  * [new All(input, [options])](#new_All_new)
  * [.topping](#All#topping) : <code>string</code>
  * [.size](#All#size)
  * ~~[.allThings(one, two)](#All#allThings) ⇒ <code>object</code> \| <code>string</code>~~
    * [~some](#All#allThings..some)

<a name="new_All_new"></a>
### new All(input, [options])
the constructor description


| Param | Type | Description |
| --- | --- | --- |
| input | <code>object</code> | an input |
| [options] | <code>object</code> | optional shit |

**Example**  
```js
var yeah = new Everything(true);
```
<a name="All#topping"></a>
### all.topping : <code>string</code>
the ingredients on top

**Default**: <code>&quot;mud, lettuce&quot;</code>  
**Kind**: instance property of <code>[All](#All)</code>  
**Since**: v1.0.0  
<a name="All#size"></a>
### all.size
the general size

**Kind**: instance property of <code>[All](#All)</code>  
<a name="All#allThings"></a>
### ~~all.allThings(one, two) ⇒ <code>object</code> \| <code>string</code>~~
***Deprecated***

This function has all tags set

**Kind**: instance method of <code>[All](#All)</code>  
**Returns**: <code>object</code> \| <code>string</code> - this return has several types  
**Since**: v0.10.28  
**Author:** Lloyd <75pound@gmail.com>  

| Param | Type | Description |
| --- | --- | --- |
| one | <code>string</code> | The input string |
| two | <code>object</code> | a second input |

**Example**  
```js
all.allTogether(true);
```
<a name="All#allThings..some"></a>
#### allThings~some
a rarseclart inner

**Kind**: inner property of <code>[allThings](#All#allThings)</code>  
