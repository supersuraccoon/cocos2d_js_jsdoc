<a name="customTaggedFunction"></a>
## customTaggedFunction()
this function has a wonderful custom tag

**Kind**: global function  
**Createdin**: Nigeria  
