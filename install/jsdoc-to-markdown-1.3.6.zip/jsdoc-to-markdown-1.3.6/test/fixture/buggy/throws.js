/**
 * @function
 * @throws {ReferenceError}
 * @throws {SyntaxError} Syntax error
 * @throws Another error, too.
 */
function foo () { }
