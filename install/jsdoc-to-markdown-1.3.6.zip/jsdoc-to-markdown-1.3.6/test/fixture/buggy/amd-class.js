/**
 * A module representing a coat.
 * @module coat
 */
define('coat', function () {
  /**
   * @constructs module:coat
   */
  function Coat () {
  }

  /** Open and close your Coat. */
  Coat.prototype.zip = function () {}

  return Coat
})

/**
 * A module representing a blouse.
 * @module blouse
 */
define('blouse', function () {
  /**
   * @constructor
   * @alias module:blouse
   */
  function Blouse () {
  }

  /** Open and close your Blouse. */
  Blouse.prototype.zip = function () {}

  return Blouse
})
