/**
 * does something
 * @class
 */
function Something () {
  /**
   * @member Something#name-format
   * @type {string}
   * @default
   */
  this['name-format'] = 'something'
}
