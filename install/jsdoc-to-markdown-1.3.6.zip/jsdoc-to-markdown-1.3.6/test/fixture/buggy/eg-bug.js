/** 
Perform foo
@example
`foo('<a href="#baz">hi!</a>');`
*/
function foo (bar) {
  return '<strong>' + bar + '</strong>'
}
