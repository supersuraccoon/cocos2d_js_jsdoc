/**
a function returning markdown
@example
this code:
var output = getMarkdown()

will assign this markdown to `output`:

**a bold heading**
a paragraph of text

*/
function getMarkdown () {}
