/**
@param {object}
*/
function operate (options) {}

/**
an object
*/
var yeah = {
  /**
  a method
  @param {string}
  */
  one: function (thing) {}
}
