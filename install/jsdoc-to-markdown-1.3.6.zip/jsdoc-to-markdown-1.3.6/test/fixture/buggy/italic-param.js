/**
 * @param {string} - input
 */
function one (_yeah) {}

/**
 * get me
 * @param {string} - whatever
 * @return {number}
 */
function two (gets) {}
