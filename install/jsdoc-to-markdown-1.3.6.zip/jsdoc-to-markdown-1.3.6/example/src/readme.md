# Some nonsense source code
Used by the examples
