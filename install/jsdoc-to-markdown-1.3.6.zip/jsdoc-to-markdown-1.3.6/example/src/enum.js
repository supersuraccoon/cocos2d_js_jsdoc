/**
@enum
*/
var eType = {
  /**
  type one
  */
  ONE: 1,
  /**
  type two
  */
  TWO: 2
}
