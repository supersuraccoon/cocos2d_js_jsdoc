/**
Pump an idiot full of volts
@deprecated
@param {object | array} - the victim(s) to fry
@param [options] {object} - electricution options
@param [options.strength=11] {number} - strength
@param [options.crazyHair=true] {number} - optional spikey hair effect
@param [options.origin] {object} - origin details
@param [options.origin.country] {string} - the country of origin
@param [done] {function} - callback on slump, which has:
- devestating power
- an unusual aftertaste
*/
function taze (victim, options, done) {}
