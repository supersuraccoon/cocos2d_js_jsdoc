# Functions
The names of all functions with params:

* plant
* protection
* taze
* spit
* spit
* battle
* method
* battle
* punch
* kill
* respect
* peace
* train
* merge
* construct
* repair

# Template
```hbs
{{#functions -params=undefined}}* {{name}}
{{/functions}}
```
