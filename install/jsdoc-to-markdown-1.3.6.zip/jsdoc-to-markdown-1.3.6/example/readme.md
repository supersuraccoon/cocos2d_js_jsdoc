# Examples
Here you see can examples of 

- how the formatting and parse options affect the output
- how to script jsdoc2md to satisfy custom requirements
- how to use selector blocks
- how all the [tags](http://usejsdoc.org) look when rendered
