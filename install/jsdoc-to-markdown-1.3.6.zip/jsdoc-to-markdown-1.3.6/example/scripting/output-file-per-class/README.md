## Output a file per class
This script (see render.js) writes documentation for each class found in the input source into a separate output file. 