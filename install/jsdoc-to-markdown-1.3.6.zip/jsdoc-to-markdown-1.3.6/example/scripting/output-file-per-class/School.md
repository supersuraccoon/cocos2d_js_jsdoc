<a name="Rapper.train..School"></a>
## train~School
**Kind**: inner class of <code>[train](#Rapper.train)</code>  

* [~School](#Rapper.train..School)
    * [new School()](#new_Rapper.train..School_new)
    * [.bestStudent](#Rapper.train..School+bestStudent)

<a name="new_Rapper.train..School_new"></a>
### new School()
rap school

<a name="Rapper.train..School+bestStudent"></a>
### school.bestStudent
best student

**Kind**: instance property of <code>[School](#Rapper.train..School)</code>  
