<a name="NewLines"></a>
## NewLines
A multi-line
class description

**Kind**: global class  

* [NewLines](#NewLines)
    * [.numbers](#NewLines+numbers)
    * [.method(input)](#NewLines+method) ⇒ <code>number</code>

<a name="NewLines+numbers"></a>
### newLines.numbers
**Kind**: instance property of <code>[NewLines](#NewLines)</code>  
**Properties**

| Name | Type | Description |
| --- | --- | --- |
| one | <code>number</code> | a property   with newlines for    a change |

<a name="NewLines+method"></a>
### newLines.method(input) ⇒ <code>number</code>
**Kind**: instance method of <code>[NewLines](#NewLines)</code>  
**Returns**: <code>number</code> - the returns
  description also 
  has newlines  

| Param | Type | Description |
| --- | --- | --- |
| input | <code>string</code> | a param description    with an awkward newline   or two. |

