<a name="Rapper"></a>
## Rapper
**Kind**: global class  

* [Rapper](#Rapper)
    * _instance_
        * [.spit()](#Rapper+spit)
        * [.battle()](#Rapper+battle)
    * _static_
        * [.train()](#Rapper.train)
            * [~School](#Rapper.train..School)
                * [new School()](#new_Rapper.train..School_new)
                * [.bestStudent](#Rapper.train..School+bestStudent)

<a name="Rapper+spit"></a>
### rapper.spit()
spit

**Kind**: instance method of <code>[Rapper](#Rapper)</code>  
<a name="Rapper+battle"></a>
### rapper.battle()
battle

**Kind**: instance method of <code>[Rapper](#Rapper)</code>  
<a name="Rapper.train"></a>
### Rapper.train()
train new rappers

**Kind**: static method of <code>[Rapper](#Rapper)</code>  

* [.train()](#Rapper.train)
    * [~School](#Rapper.train..School)
        * [new School()](#new_Rapper.train..School_new)
        * [.bestStudent](#Rapper.train..School+bestStudent)

<a name="Rapper.train..School"></a>
#### train~School
**Kind**: inner class of <code>[train](#Rapper.train)</code>  

* [~School](#Rapper.train..School)
    * [new School()](#new_Rapper.train..School_new)
    * [.bestStudent](#Rapper.train..School+bestStudent)

<a name="new_Rapper.train..School_new"></a>
##### new School()
rap school

<a name="Rapper.train..School+bestStudent"></a>
##### school.bestStudent
best student

**Kind**: instance property of <code>[School](#Rapper.train..School)</code>  
