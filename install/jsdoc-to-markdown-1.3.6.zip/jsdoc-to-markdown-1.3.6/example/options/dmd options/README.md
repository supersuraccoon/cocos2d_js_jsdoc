The `readme.md` in each of these sub-folders highlights the affects of the corresponding jsdoc2md options.. Each of these options are passed to dmd..
