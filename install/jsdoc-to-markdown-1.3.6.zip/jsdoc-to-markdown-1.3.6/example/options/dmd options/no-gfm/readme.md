## `--no-gfm`
This folder contains examples highlighting how `--no-gfm` affect certain templates.. 
