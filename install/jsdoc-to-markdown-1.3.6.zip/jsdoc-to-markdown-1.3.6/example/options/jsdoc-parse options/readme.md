# parse options

These options are passed to jsdoc-parse. 