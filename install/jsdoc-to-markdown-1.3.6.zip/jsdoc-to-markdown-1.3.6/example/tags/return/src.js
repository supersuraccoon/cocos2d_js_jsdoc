/**
@returns {string}
*/
function returnsSomething () {}

/**
@returns {string} returns a string
*/
function returnsWithDesc () {}
