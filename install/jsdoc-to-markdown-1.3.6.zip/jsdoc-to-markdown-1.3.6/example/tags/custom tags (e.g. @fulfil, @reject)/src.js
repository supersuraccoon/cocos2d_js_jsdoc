/**
@fulfil {Tree} - Fulfils with a damn tree
@reject {Error} This is an error which is passed back
@returns {Promise}
*/
function promiseSomething () {}

/**
@class
*/
function Tree () {}

/**
@cast in order of appearance:
1. David Jason
2. Nicholas Lyndhurst
3. Buster Merryfield
*/
function Comedy () {}
